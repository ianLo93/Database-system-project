package create.database;
import connect.database.*;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;


public class Mongodb {
	public static void main(String [] argc) {
		DB db = ConnectMongodb.connect2database();
		
		
	}

}
