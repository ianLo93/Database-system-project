package create.database;

import java.sql.*;
import java.util.*;

import connect.database.ConnectPostgre;

public class FindResults {

	static Connection conn;
	static PreparedStatement pst;
	
	public static List<Item> getResults(ResultBean u) {
		ResultSet result = null;
		List<Item> itemLs = new ArrayList<Item>();
		String sql = "SELECT unitid, instnm, new_tab.state, new_tab.city FROM college_info JOIN ( " + 
				"SELECT * FROM city JOIN statechart ON city.stabbr = statechart.abb " + 
				") AS new_tab ON new_tab.zip = college_info.zip WHERE instnm ILIKE ";
		if(u.getSchool()!=null)
			sql = sql+"$$%"+u.getSchool()+"%$$";
		else
			sql = sql + "$$%%$$ ";
		if(u.getZip()!=0) 
			sql = sql+"AND new_tab.zip="+u.getZip()+" ";
		if(u.getState()!=null)
			sql = sql+"AND new_tab.state =$$"+u.getState()+"$$ ";
		if(u.getCity()!=null)
			sql = sql+"AND new_tab.city ILIKE $$%"+u.getCity()+"%$$";
		System.out.println(sql);

		try{
			conn = ConnectPostgre.connect2database();
			pst = conn.prepareStatement(sql);
			result = pst.executeQuery();
			while(result.next()) {
				Item x = new Item(result.getInt("unitid"), result.getString("instnm"), result.getString("state"), result.getString("city"));
				itemLs.add(x);
			}
			conn.close();
		 } catch(Exception ex) {
			System.out.print(ex);
		}
		return itemLs;
	}
	
	public static void getDetailed(DetailBean u) {
		ResultSet result = null;
		String sql = "SELECT college_info.unitid, college_info.opeid, college_info.instnm, "+
		"college_info.accredagency, college_info.insturl, college_info.npcurl, college_info.numbranch,"+
		" college_info.menonly, college_info.womenonly, college_info.age_entry, college_info.avgfacsal,"
		+ " college_info.grads, college_info.female, college_info.married, college_info.ugds_men,"+
		"college_info.ugds_women, college_info.sat_avg, college_info.latitude, college_info.longitude,"+
		" city.zip, city.city, city.region, city.locale"+
		" FROM (SELECT * FROM college_info JOIN accredagency ON college_info.accredcode=accredagency.accredcode) AS college_info"+
		" JOIN city on college_info.zip = city.zip WHERE unitid=?";
		
		System.out.println(sql);
		
		try {
			conn = ConnectPostgre.connect2database();
			pst = conn.prepareStatement(sql);
			pst.setInt(1, u.getUnitid());
			result = pst.executeQuery();
			result.next();
			u.setAccredagency(result.getString("accredagency"));
			u.setAge_entry(result.getFloat("age_entry"));
			u.setAvgfacsal(result.getInt("avgfacsal"));
			u.setCity(result.getString("city"));
			u.setFemale(result.getFloat("female"));
			u.setGrads(result.getInt("grads"));
			u.setInstnm(result.getString("instnm"));
			u.setInsturl(result.getString("insturl"));
			u.setLatitude(result.getFloat("latitude"));
			u.setLocale(result.getInt("locale"));
			u.setLongitude(result.getFloat("longitude"));
			u.setMarried(result.getFloat("married"));
			u.setMenonly(result.getBoolean("menonly"));
			u.setNpcurl(result.getString("npcurl"));
			u.setNumbranch(result.getInt("numbranch"));
			u.setOpeid(result.getInt("opeid"));
			u.setRegion(result.getInt("region"));
			u.setUnitid(result.getInt("unitid"));
			u.setSat_avg(result.getInt("sat_avg"));
			u.setUgds_men(result.getFloat("ugds_men"));
			u.setUgds_women(result.getFloat("ugds_women"));
			u.setWomenonly(result.getBoolean("womenonly"));
			u.setZip(result.getInt("zip"));
			
			conn.close();
		} catch(Exception ex) {
			System.out.println(ex);
		}
		
	}
}
	
