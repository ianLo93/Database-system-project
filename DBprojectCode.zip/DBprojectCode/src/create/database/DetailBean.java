package create.database;

public class DetailBean {

	private int unitid;
	private int opeid;
	private String instnm;
	private String accredagency;
	private String insturl;
	private String npcurl;
	private int numbranch;
	private boolean menonly;
	private boolean womenonly;
	private float age_entry;
	private int avgfacsal;
	private int grads;
	private float female;
	private float married;
	private float ugds_men;
	private float ugds_women;
	private int sat_avg;
	private float latitude;
	private float longitude;
	private int zip;
	private String city;
	private int region;
	private int locale;
	
	public int getRegion() {
		return region;
	}
	public void setRegion(int region) {
		this.region = region;
	}
	public int getLocale() {
		return locale;
	}
	public int getSat_avg() {
		return sat_avg;
	}
	public void setSat_avg(int sat_avg) {
		this.sat_avg = sat_avg;
	}
	public void setLocale(int locale) {
		this.locale = locale;
	}

	public int getUnitid() {
		return unitid;
	}
	public void setUnitid(int unitid) {
		this.unitid = unitid;
	}
	public int getOpeid() {
		return opeid;
	}
	public void setOpeid(int opeid) {
		this.opeid = opeid;
	}
	public String getInstnm() {
		return instnm;
	}
	public void setInstnm(String instnm) {
		this.instnm = instnm;
	}
	
	public String getAccredagency() {
		return accredagency;
	}
	public void setAccredagency(String accredagency) {
		this.accredagency = accredagency;
	}
	public String getInsturl() {
		return insturl;
	}
	public void setInsturl(String insturl) {
		this.insturl = insturl;
	}
	public String getNpcurl() {
		return npcurl;
	}
	public void setNpcurl(String npcurl) {
		this.npcurl = npcurl;
	}
	public int getNumbranch() {
		return numbranch;
	}
	public void setNumbranch(int numbranch) {
		this.numbranch = numbranch;
	}
	public boolean isMenonly() {
		return menonly;
	}
	public void setMenonly(boolean menonly) {
		this.menonly = menonly;
	}
	public boolean isWomenonly() {
		return womenonly;
	}
	public void setWomenonly(boolean womenonly) {
		this.womenonly = womenonly;
	}
	public float getAge_entry() {
		return age_entry;
	}
	public void setAge_entry(float age_entry) {
		this.age_entry = age_entry;
	}
	public int getAvgfacsal() {
		return avgfacsal;
	}
	public void setAvgfacsal(int avgfacsal) {
		this.avgfacsal = avgfacsal;
	}
	public int getGrads() {
		return grads;
	}
	public void setGrads(int grads) {
		this.grads = grads;
	}
	public float getFemale() {
		return female;
	}
	public void setFemale(float female) {
		this.female = female;
	}
	public float getMarried() {
		return married;
	}
	public void setMarried(float married) {
		this.married = married;
	}
	public float getUgds_men() {
		return ugds_men;
	}
	public void setUgds_men(float ugds_men) {
		this.ugds_men = ugds_men;
	}
	public float getUgds_women() {
		return ugds_women;
	}
	public void setUgds_women(float ugds_women) {
		this.ugds_women = ugds_women;
	}
	public float getLatitude() {
		return latitude;
	}
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}
	public float getLongitude() {
		return longitude;
	}
	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	
}