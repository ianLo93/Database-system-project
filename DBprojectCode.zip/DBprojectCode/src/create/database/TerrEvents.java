package create.database;
import connect.database.*;
import connect.database.ConnectMongodb;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.client.*;
import java.util.*;
import java.util.regex.Pattern;

public class TerrEvents {
	Map<String, EventDetail> events = new HashMap<String, EventDetail>();
	public Map<String, EventDetail> getEvents() {
		return events;
	}
	private void setEvents(Map<String, EventDetail> events) {
		this.events = events;
	}
	public TerrEvents() {
		
	}
	public void Find(Map<String, String> data) {
		try {

		DB db = ConnectMongodb.connect2database();
		DBCollection coll = db.getCollection("terr");
		BasicDBObject fields = new BasicDBObject();
		BasicDBObject query = new BasicDBObject();
		fields.put("_id", 1);
		for (Map.Entry<String, String> entry : data.entrySet()) {
		    String key = entry.getKey();
		    String value = entry.getValue();
		    System.out.println(key + ": " + value);
		    if(key.equals("include")) {
		    		if (value.equals("false")) {
		    			query.put("success", 1);
		    		}
		    }else if(key.equals("iyear")){
		    		query.put(key, Integer.valueOf(value));
		    }
		    else {
		    		query.put(key, Pattern.compile(value , Pattern.CASE_INSENSITIVE));
		    }
		    
		}
//		System.out.println(query);
		DBCursor cursor = coll.find(query, fields);
		int i = 1;
		while(cursor.hasNext() && i < 10) {
			System.out.println("yes " + cursor.next());
			BasicDBObject dbObject = (BasicDBObject)cursor.next();
			String id = dbObject.getString("_id");
//			System.out.println(id);
			events.put(id, new EventDetail(id));
			i++;
		}

		
		}catch(Exception ex){}	
	}

}
