package create.database;
import connect.database.*;

import java.sql.*;
import java.util.*;
import java.io.*;


public class Postgredb {
	
	private Scanner x;
	
	public void OpenFile() {
		try {
			x = new Scanner(new File("test2.txt"));
		}catch(Exception e){
			System.out.println("Error");
			System.out.println(e);
		}
	}
	
	public void ReadFile() {
		while(x.hasNext()) {
			 String a = x.next();
			 String b = x.next();
			 String c = x.next();
			 System.out.printf("%s %s %s\n", a,b,c);
		}
	}
	
	public void CloseFile() {
		x.close();
	}
	
//	public static void main(String [] args) {
//		Postgredb r = new Postgredb();
//		r.OpenFile();
//		r.ReadFile();
//		r.CloseFile();
//		
//	}
	
	   public static void main(String[] args) {

	        String csvFile = "CollegeData2.1.csv";
	        String line = "";
	        String cvsSplitBy = ",";
	        String sql_1 = "";
	        String sql_2 = "";
	        String sql_3 = "";
      
	        ArrayList<String> SQL_1 = new ArrayList<String>();
	        ArrayList<String> SQL_2 = new ArrayList<String>();
	        ArrayList<String> SQL_3 = new ArrayList<String>();
	        
	        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	        		line = br.readLine();
	            while ((line = br.readLine()) != null) {

	                String[] tuple = line.split(cvsSplitBy);
	                
	                if(tuple[3].length() > 4) tuple[3] = tuple[3].substring(0, 5);
	                tuple[20] = tuple[3];
	                if(tuple.length<29) continue;

	                for (int i = 0; i < tuple.length; i++) {
	                		
	                		if(i == 0 || i == 1 || i == 3 || i == 7 || (i >= 10 && i <= 20 ) || i == 23 || i == 24) { 
	                			if (tuple[i].equals("PrivacySuppressed") || tuple[i].equals("") ) {tuple[i] = "NULL";}
	                		}
	                		else {
	                			//System.out.println(i + tuple[i]);
	                			if (tuple[i].equals("PrivacySuppressed")|| tuple[i].toUpperCase().equals("NULL") || tuple[i] == "") tuple[i] = "NULL";
	                			else tuple[i] = "'"+tuple[i]+"'";
	                		}	                	
	                }

	                
	                if(tuple[0]!="NULL") sql_1 = "INSERT INTO College_info VALUES ("+tuple[0]+", "+tuple[1]+", "+ tuple[2]+", "+tuple[3]+", "+tuple[4]+", "+ tuple[5]+", "+tuple[6]+", "+tuple[7]+", "+ tuple[8]+", "+ tuple[9]+", "+tuple[10]+", "+tuple[11]+", "+tuple[12]+", "+tuple[13]+", "+ tuple[14]+", "+tuple[15]+", "+ tuple[16]+", "+ tuple[17]+", "+ tuple[18]+", "+ tuple[19]+" )";
	                if(tuple[20]!="NULL") sql_2 = "INSERT INTO City VALUES ("+tuple[20]+", "+ tuple[21]+", "+ tuple[22]+", "+ tuple[23]+", "+ tuple[24]+")";
	                if(tuple[25]!="NULL") sql_3 = "INSERT INTO Accredagency VALUES ("+tuple[25]+", "+ tuple[26]+", "+ tuple[27]+", "+ tuple[28]+")";
	                
	                if(tuple[25]=="MI") {
	                		System.out.println(sql_1);
	                		break;
	                }
	                
	                SQL_1.add(sql_1);
	                SQL_2.add(sql_2);
	                SQL_3.add(sql_3);
	            }

	        } catch (IOException e) {
	        		
	            e.printStackTrace();
	            System.out.println(e.getMessage());
	        }
	        
	        System.out.println("finish reading data, now begin insert to database");
	        System.out.println(SQL_1.size());
	        
	        Connection con = ConnectPostgre.connect2database();
	        
	        for(int i = 0; i < SQL_1.size(); i++) {
	        		String sql = SQL_1.get(i);
	        		System.out.println(sql);
	        		try{
	        			PreparedStatement st = con.prepareStatement(sql);	
	        			int insert_result = st.executeUpdate();
	        			if (insert_result==0) System.out.println("Fail");
	        			
	        		}catch (Exception e) {
	        			System.out.println("There are some problems:");
	        			System.out.println(e.getMessage());
	        			e.printStackTrace();
	        		}
	        }
	        System.out.println("finish college_info");
	        
	        ArrayList<String> zip_key = new ArrayList<String>();
	        for(int i = 0; i <SQL_2.size(); i++) {
        			String sql = SQL_2.get(i);
        			String zip = sql.substring(25, 30);
        			// System.out.println(zip);
        			if (zip_key.contains(zip)) continue;
        			else zip_key.add(zip);
        			try{
        				PreparedStatement st = con.prepareStatement(sql);	
        				int insert_result = st.executeUpdate();
        				if (insert_result==0) System.out.println("Fail");
        			
        			}catch (Exception e) {
        				//System.out.println("There are some problems:");
        				System.out.println(e.getMessage());
        				//e.printStackTrace();
        			}
	        }
	        System.out.println("finish city");
	        ArrayList<String> code_key = new ArrayList<String>();
	        for(int i = 0; i <SQL_3.size(); i++) {
    				String sql = SQL_3.get(i);
    				String code = sql.substring(34,40);
    				//System.out.println(code);
    				if (code_key.contains(code)) continue;
    				else code_key.add(code);
    				try{
    					PreparedStatement st = con.prepareStatement(sql);	
    					int insert_result = st.executeUpdate();
    					if (insert_result==0) System.out.println("Fail");
    			
    				}catch (Exception e) {
    					e.printStackTrace();
    					System.out.println(SQL_1.get(i));
    					System.out.println(SQL_2.get(i));
    					System.out.println(sql);
    					//System.out.println(e.getMessage());
    					//e.printStackTrace();
    					
    				}
	        }
	        System.out.println("finish!!!");
	        

	    }

	
	public static boolean create(String filename) {
        String csvFile = "test2.1.csv";
        String line = "";
        String cvsSplitBy = ",";


			
		return true;
		
	}
}
