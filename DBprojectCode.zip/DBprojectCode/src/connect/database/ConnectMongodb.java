package connect.database;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;


public class ConnectMongodb {
//	public static void main(String[] args) throws Exception{
//		
//		
//		try {
//			MongoClient mongoclient = new MongoClient("localhost",27017);
//			DB db = mongoclient.getDB("company");
//			System.out.println("Connecting");
//			
//			DBCollection coll = db.getCollection("ceo");
//			DBCursor cursor = coll.find();
//		
//			
//			while(cursor.hasNext()) {
//				int i = 1;
//				System.out.println(cursor.next());
//				i++;
//			}
//			
//		}catch(Exception ex) {
//			
//			System.out.println("Connection Failed");
//			System.out.println(ex);
//		}
//		System.out.println("Server is ready!");
//		
//	}
	
	
	public static DB connect2database(){
	
		try {
			MongoClient mongoclient = new MongoClient("localhost",27017);
			DB db = mongoclient.getDB("company");
			System.out.println("Connecting");
			return db;
			
		}catch(Exception ex) {
			
			System.out.println("Connection Failed");
			System.out.println(ex);
			return null;
		}
		
		
	}
	
	public static void main(String[] args) throws Exception{
		DB database = connect2database(); 
		DBCollection coll = database.getCollection("ceo");
		DBCursor cursor = coll.find();
		
	
			
		while(cursor.hasNext()) {
			int i = 1;
			System.out.println(cursor.next());
			i++;
		}
			
		
		System.out.println("Server is ready!");
		
	}

}
