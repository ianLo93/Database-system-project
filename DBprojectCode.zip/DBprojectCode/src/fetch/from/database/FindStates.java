package fetch.from.database;

import java.sql.*;
import java.util.*;

import connect.database.ConnectPostgre;

public class FindStates {

	static Connection conn;
	static PreparedStatement pst;
	
	public static List<String> retriveStates() {
		ResultSet result = null;
		List<String> states = new ArrayList<String>();
		String sql = "SELECT state FROM statechart;";
		
		try {
			conn = ConnectPostgre.connect2database();
			pst = conn.prepareStatement(sql);
			result = pst.executeQuery();
			while(result.next()) {
				states.add(result.getString(1));
			}
		} catch(Exception ex) {
			System.out.println(ex);
		}
		return states;
	}

}
