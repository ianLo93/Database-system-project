package fetch.from.database;
import connect.database.*;
import connect.database.ConnectMongodb;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.client.*;
import java.util.*;
import org.bson.types.ObjectId;

import org.bson.Document;

public class EventDetail {


	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getAddnotes() {
		return addnotes;
	}

	public void setAddnotes(String addnotes) {
		this.addnotes = addnotes;
	}

	public String getAttack_type() {
		return attack_type;
	}

	public void setAttack_type(String attack_type) {
		this.attack_type = attack_type;
	}

	public String getTarget_type() {
		return target_type;
	}

	public void setTarget_type(String target_type) {
		this.target_type = target_type;
	}

	public String getWeapon_type() {
		return weapon_type;
	}

	public void setWeapon_type(String weapon_type) {
		this.weapon_type = weapon_type;
	}

	public String getDbsource() {
		return dbsource;
	}

	public void setDbsource(String dbsource) {
		this.dbsource = dbsource;
	}

	public String Id;
	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String year;
	public String month;
	public String date;
	public String state="";
	public String city="";
	public String location="";
	public String summary="";
	public String addnotes;
	public String attack_type="";
	public String target_type="";
	public String weapon_type="";
	public String dbsource="";
	public String getInternational() {
		return international;
	}

	public void setInternational(String international) {
		this.international = international;
	}

	public String getMotivation() {
		return motivation;
	}

	public void setMotivation(String motivation) {
		this.motivation = motivation;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String international = "";
	public String motivation = "";
	public String latitude = "";
	public String longitude = "";
	
	public EventDetail(String ID) {
		System.out.println(ID);
		this.Id = ID;
		
		try {
		DB db = ConnectMongodb.connect2database();
		DBCollection coll = db.getCollection("terrorism");
		BasicDBObject fields = new BasicDBObject();
		BasicDBObject query = new BasicDBObject();
		query.put("_id", new ObjectId(Id));
		DBCursor cursor = coll.find(query);
		
		BasicDBObject dbObject = (BasicDBObject)cursor.next();
		this.year = dbObject.getString("iyear");
		this.month = dbObject.getString("imonth");
		this.date = dbObject.getString("iday");
		this.state = dbObject.getString("provstate");
		this.city = dbObject.getString("city");
		this.location = dbObject.getString("location");
		this.summary = dbObject.getString("summary");
		this.attack_type = dbObject.getString("attacktype1_txt");
		this.target_type = dbObject.getString("targtype1_txt");
		this.weapon_type = dbObject.getString("weaptype1_txt");
		this.dbsource = dbObject.getString("dbsource");
		this.addnotes = dbObject.getString("addnotes");
		this.international = dbObject.getString("INT_ANY");
		this.motivation = dbObject.getString("motive");
		this.latitude = dbObject.getString("latitude");
		this.longitude = dbObject.getString("longitude");
		
		}catch(Exception ex){}	
		
	}
	
	
}
