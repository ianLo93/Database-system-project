package fetch.from.database;

public class Item {

	private String school;
	private String state;
	private String city;
	private int unitid;
	
	public Item(int unitid, String school, String state, String city) {
		this.school=school;
		this.state=state;
		this.city=city;
		this.unitid = unitid;
	}
	
	public int getUnitid() {
		return unitid;
	}

	public void setUnitid(int unitid) {
		this.unitid = unitid;
	}

	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
}
